#!/bin/bash

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;36m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# Banner
clear
echo -e "${MAGENTA}"
cat << "EOF"
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   ███████╗███╗   ██╗██████╗       ██╗  ██╗                  ║
║   ██╔════╝████╗  ██║██╔══██╗      ██║  ██║                  ║
║   █████╗  ██╔██╗ ██║██║  ██║█████╗███████║                  ║
║   ██╔══╝  ██║╚██╗██║██║  ██║╚════╝╚════██║                  ║
║   ███████╗██║ ╚████║██████╔╝           ██║                  ║
║   ╚══════╝╚═╝  ╚═══╝╚═════╝            ╚═╝                  ║
║                                                               ║
║             GRUVBOX DESKTOP ENVIRONMENT                       ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

echo -e "${CYAN}Complete Gruvbox-themed desktop with:${NC}"
echo "  • Hyprland + QuickShell"
echo "  • Plymouth Rubik's Cube boot animation"
echo "  • GTK/Qt/Kvantum theming"
echo "  • Oreo Gruvbox cursor"
echo "  • Dolphin file manager integration"
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo -e "${RED}Do not run this script as root!${NC}"
   echo "Run as your normal user. sudo will be requested when needed."
   exit 1
fi

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${YELLOW}Installation will modify system files and configurations.${NC}"
echo "Backups will be created automatically."
echo ""
read -p "Continue with installation? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
fi

# Create backup directory
BACKUP_DIR="$HOME/Backups/pre-gruvbox-install-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
echo -e "${GREEN}Backup directory: $BACKUP_DIR${NC}"
echo ""

# ============================================================================
# STEP 1: SYSTEM UPDATE
# ============================================================================
echo -e "${BLUE}[1/12] Updating system...${NC}"
sudo pacman -Syu --noconfirm
echo -e "${GREEN}  ✓ System updated${NC}"
echo ""

# ============================================================================
# STEP 2: INSTALL BASE PACKAGES
# ============================================================================
echo -e "${BLUE}[2/12] Installing base packages...${NC}"

BASE_PACKAGES=(
    # Hyprland and Wayland
    "hyprland"
    "xdg-desktop-portal-hyprland"
    "qt5-wayland"
    "qt6-wayland"
    
    # Display and graphics
    "wl-clipboard"
    "grim"
    "slurp"
    
    # Audio
    "pipewire"
    "pipewire-pulse"
    "wireplumber"
    
    # Network
    "networkmanager"
    
    # Bluetooth
    "bluez"
    "bluez-utils"
    
    # File manager
    "dolphin"
    
    # Plymouth
    "plymouth"
    
    # Fonts
    "ttf-jetbrains-mono-nerd"
    "ttf-font-awesome"
    "noto-fonts"
    "noto-fonts-emoji"
    
    # Theme engines
    "gtk3"
    "gtk4"
    "qt5ct"
    "qt6ct"
    "kvantum"
    
    # Image manipulation
    "imagemagick"
    
    # Utilities
    "git"
    "base-devel"
)

echo "Installing ${#BASE_PACKAGES[@]} packages..."
sudo pacman -S --needed --noconfirm "${BASE_PACKAGES[@]}"

echo -e "${GREEN}  ✓ Base packages installed${NC}"
echo ""

# ============================================================================
# STEP 3: INSTALL AUR PACKAGES
# ============================================================================
echo -e "${BLUE}[3/12] Installing AUR packages...${NC}"

# Check for AUR helper
if ! command -v yay &>/dev/null && ! command -v paru &>/dev/null; then
    echo "No AUR helper found. Installing yay..."
    cd /tmp
    git clone https://aur.archlinux.org/yay.git
    cd yay
    makepkg -si --noconfirm
    cd "$SCRIPT_DIR"
fi

AUR_HELPER="yay"
command -v paru &>/dev/null && AUR_HELPER="paru"

AUR_PACKAGES=(
    "quickshell-git"
    "hyprcursor"
)

echo "Installing AUR packages with $AUR_HELPER..."
$AUR_HELPER -S --needed --noconfirm "${AUR_PACKAGES[@]}" || echo "Some AUR packages may have failed"

echo -e "${GREEN}  ✓ AUR packages installed${NC}"
echo ""

# ============================================================================
# STEP 4: BACKUP EXISTING CONFIGS
# ============================================================================
echo -e "${BLUE}[4/12] Backing up existing configurations...${NC}"

CONFIGS_TO_BACKUP=(
    "$HOME/.config/quickshell"
    "$HOME/.config/hypr"
    "$HOME/.config/gtk-3.0"
    "$HOME/.config/gtk-4.0"
    "$HOME/.config/Kvantum"
    "$HOME/.config/dolphinrc"
    "$HOME/.config/kdeglobals"
)

for config in "${CONFIGS_TO_BACKUP[@]}"; do
    if [ -e "$config" ]; then
        cp -r "$config" "$BACKUP_DIR/" 2>/dev/null || true
        echo "  - Backed up: $(basename $config)"
    fi
done

echo -e "${GREEN}  ✓ Configurations backed up${NC}"
echo ""

# ============================================================================
# STEP 5: INSTALL QUICKSHELL CONFIGURATION
# ============================================================================
echo -e "${BLUE}[5/12] Installing QuickShell configuration...${NC}"

if [ -d "$SCRIPT_DIR/config/quickshell" ]; then
    mkdir -p "$HOME/.config/quickshell"
    cp -r "$SCRIPT_DIR/config/quickshell/"* "$HOME/.config/quickshell/"
    echo "  - QuickShell config installed"
    echo "  - Includes: Media player fixes, resource monitors"
else
    echo -e "${YELLOW}  - QuickShell config not found in repository${NC}"
fi

echo -e "${GREEN}  ✓ QuickShell configured${NC}"
echo ""

# ============================================================================
# STEP 6: INSTALL HYPRLAND CONFIGURATION
# ============================================================================
echo -e "${BLUE}[6/12] Installing Hyprland configuration...${NC}"

if [ -d "$SCRIPT_DIR/config/hypr" ]; then
    mkdir -p "$HOME/.config/hypr"
    cp -r "$SCRIPT_DIR/config/hypr/"* "$HOME/.config/hypr/"
    echo "  - Hyprland config installed"
else
    echo -e "${YELLOW}  - Hyprland config not found in repository${NC}"
fi

echo -e "${GREEN}  ✓ Hyprland configured${NC}"
echo ""

# ============================================================================
# STEP 7: INSTALL THEMES
# ============================================================================
echo -e "${BLUE}[7/12] Installing Gruvbox themes...${NC}"

# GTK themes
if [ -d "$SCRIPT_DIR/themes/gtk" ]; then
    mkdir -p "$HOME/.config/gtk-3.0" "$HOME/.config/gtk-4.0"
    cp -r "$SCRIPT_DIR/themes/gtk/gtk-3.0/"* "$HOME/.config/gtk-3.0/" 2>/dev/null || true
    cp -r "$SCRIPT_DIR/themes/gtk/gtk-4.0/"* "$HOME/.config/gtk-4.0/" 2>/dev/null || true
    echo "  - GTK themes installed"
fi

# Qt/Kvantum themes
if [ -d "$SCRIPT_DIR/themes/qt" ]; then
    mkdir -p "$HOME/.config/Kvantum"
    cp -r "$SCRIPT_DIR/themes/qt/Kvantum/"* "$HOME/.config/Kvantum/" 2>/dev/null || true
    cp -r "$SCRIPT_DIR/themes/qt/qt5ct" "$HOME/.config/" 2>/dev/null || true
    cp -r "$SCRIPT_DIR/themes/qt/qt6ct" "$HOME/.config/" 2>/dev/null || true
    echo "  - Qt/Kvantum themes installed"
fi

# Color schemes
if [ -d "$SCRIPT_DIR/themes/color-schemes" ]; then
    mkdir -p "$HOME/.local/share/color-schemes"
    cp "$SCRIPT_DIR/themes/color-schemes/"*.colors "$HOME/.local/share/color-schemes/" 2>/dev/null || true
    echo "  - Color schemes installed"
fi

# KDE globals
if [ -f "$SCRIPT_DIR/themes/kdeglobals" ]; then
    cp "$SCRIPT_DIR/themes/kdeglobals" "$HOME/.config/"
    echo "  - KDE globals installed"
fi

echo -e "${GREEN}  ✓ Themes installed${NC}"
echo ""

# ============================================================================
# STEP 8: INSTALL CURSOR THEME
# ============================================================================
echo -e "${BLUE}[8/12] Installing Oreo Gruvbox cursor theme...${NC}"

if [ -d "$SCRIPT_DIR/themes/cursors/Oreo-Gruvbox" ]; then
    mkdir -p "$HOME/.local/share/icons"
    cp -r "$SCRIPT_DIR/themes/cursors/Oreo-Gruvbox" "$HOME/.local/share/icons/"
    echo "  - Oreo Gruvbox cursor installed"
    
    # Set cursor theme in Hyprland
    if [ -f "$HOME/.config/hypr/hyprland.conf" ]; then
        if ! grep -q "Oreo-Gruvbox" "$HOME/.config/hypr/hyprland.conf"; then
            echo "exec-once = hyprctl setcursor Oreo-Gruvbox 24" >> "$HOME/.config/hypr/hyprland.conf"
        fi
    fi
else
    echo -e "${YELLOW}  - Cursor theme not found in repository${NC}"
fi

echo -e "${GREEN}  ✓ Cursor theme installed${NC}"
echo ""

# ============================================================================
# STEP 9: INSTALL FONTS
# ============================================================================
echo -e "${BLUE}[9/12] Installing fonts...${NC}"

if [ -d "$SCRIPT_DIR/fonts" ]; then
    mkdir -p "$HOME/.local/share/fonts"
    cp -r "$SCRIPT_DIR/fonts/"* "$HOME/.local/share/fonts/" 2>/dev/null || true
    fc-cache -fv
    echo "  - Fonts installed and cache updated"
else
    echo "  - Using system fonts"
fi

echo -e "${GREEN}  ✓ Fonts configured${NC}"
echo ""

# ============================================================================
# STEP 10: INSTALL PLYMOUTH BOOT ANIMATION
# ============================================================================
echo -e "${BLUE}[10/12] Installing Plymouth boot animation...${NC}"

if [ -d "$SCRIPT_DIR/plymouth/gruvbox-rubiks" ]; then
    echo "This requires sudo privileges..."
    
    # Copy theme
    sudo cp -r "$SCRIPT_DIR/plymouth/gruvbox-rubiks" /usr/share/plymouth/themes/
    
    # Set as default
    sudo plymouth-set-default-theme gruvbox-rubiks
    
    # Check if plymouth is in mkinitcpio hooks
    if ! grep -q "plymouth" /etc/mkinitcpio.conf; then
        echo "  - Adding plymouth to mkinitcpio hooks..."
        sudo cp /etc/mkinitcpio.conf /etc/mkinitcpio.conf.backup
        sudo sed -i 's/\(HOOKS=([^)]*\))/\1 plymouth)/' /etc/mkinitcpio.conf
    fi
    
    # Update GRUB
    if [ -f /etc/default/grub ]; then
        if ! grep -q "quiet splash" /etc/default/grub; then
            echo "  - Adding 'quiet splash' to GRUB..."
            sudo cp /etc/default/grub /etc/default/grub.backup
            sudo sed -i 's/\(GRUB_CMDLINE_LINUX_DEFAULT="[^"]*\)/\1 quiet splash/' /etc/default/grub
            sudo grub-mkconfig -o /boot/grub/grub.cfg
        fi
    fi
    
    # Rebuild initramfs
    echo "  - Rebuilding initramfs..."
    sudo mkinitcpio -P
    
    echo "  - Plymouth Gruvbox Rubik's Cube installed"
else
    echo -e "${YELLOW}  - Plymouth theme not found in repository${NC}"
fi

echo -e "${GREEN}  ✓ Plymouth configured${NC}"
echo ""

# ============================================================================
# STEP 11: CONFIGURE APPLICATIONS
# ============================================================================
echo -e "${BLUE}[11/12] Configuring applications...${NC}"

# Dolphin
if [ -f "$SCRIPT_DIR/config/dolphin/dolphinrc" ]; then
    cp "$SCRIPT_DIR/config/dolphin/dolphinrc" "$HOME/.config/"
    echo "  - Dolphin configured"
fi

# Terminal (if present)
if [ -d "$SCRIPT_DIR/config/misc/kitty" ]; then
    mkdir -p "$HOME/.config/kitty"
    cp -r "$SCRIPT_DIR/config/misc/kitty/"* "$HOME/.config/kitty/" 2>/dev/null || true
    echo "  - Kitty terminal configured"
fi

if [ -d "$SCRIPT_DIR/config/misc/alacritty" ]; then
    mkdir -p "$HOME/.config/alacritty"
    cp -r "$SCRIPT_DIR/config/misc/alacritty/"* "$HOME/.config/alacritty/" 2>/dev/null || true
    echo "  - Alacritty terminal configured"
fi

echo -e "${GREEN}  ✓ Applications configured${NC}"
echo ""

# ============================================================================
# STEP 12: FINALIZE
# ============================================================================
echo -e "${BLUE}[12/12] Finalizing installation...${NC}"

# Set environment variables
cat > "$HOME/.config/hypr/env.conf" << 'ENVCONF'
# Qt theming
env = QT_QPA_PLATFORMTHEME,qt5ct
env = QT_STYLE_OVERRIDE,kvantum

# Wayland
env = QT_QPA_PLATFORM,wayland
env = GDK_BACKEND,wayland
env = SDL_VIDEODRIVER,wayland
env = CLUTTER_BACKEND,wayland

# XDG
env = XDG_CURRENT_DESKTOP,Hyprland
env = XDG_SESSION_TYPE,wayland
env = XDG_SESSION_DESKTOP,Hyprland

# Cursor
env = XCURSOR_THEME,Oreo-Gruvbox
env = XCURSOR_SIZE,24
ENVCONF

# Source env.conf in Hyprland config if not already there
if [ -f "$HOME/.config/hypr/hyprland.conf" ]; then
    if ! grep -q "source.*env.conf" "$HOME/.config/hypr/hyprland.conf"; then
        echo "source = ~/.config/hypr/env.conf" >> "$HOME/.config/hypr/hyprland.conf"
    fi
fi

# Create desktop entry for Hyprland
sudo tee /usr/share/wayland-sessions/hyprland-gruvbox.desktop > /dev/null << 'DESKTOPENTRY'
[Desktop Entry]
Name=Hyprland (Gruvbox)
Comment=Hyprland with Gruvbox theming
Exec=Hyprland
Type=Application
DESKTOPENTRY

echo -e "${GREEN}  ✓ Installation finalized${NC}"
echo ""

# ============================================================================
# COMPLETION MESSAGE
# ============================================================================
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                               ║${NC}"
echo -e "${GREEN}║              INSTALLATION COMPLETE! 🎉                        ║${NC}"
echo -e "${GREEN}║                                                               ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}What's been installed:${NC}"
echo "  ✓ Hyprland window manager with Gruvbox theme"
echo "  ✓ QuickShell status bar (with media/swap fixes)"
echo "  ✓ Plymouth Rubik's Cube boot animation"
echo "  ✓ Complete Gruvbox theming (GTK/Qt/Kvantum)"
echo "  ✓ Oreo Gruvbox cursor theme"
echo "  ✓ Dolphin file manager integration"
echo "  ✓ Fonts and icons"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "  1. Log out of your current session"
echo "  2. Select 'Hyprland (Gruvbox)' from your display manager"
echo "  3. Log in to see your beautiful Gruvbox desktop!"
echo "  4. Reboot to see the Plymouth boot animation"
echo ""
echo -e "${CYAN}Backup location:${NC} $BACKUP_DIR"
echo ""
echo -e "${CYAN}Configuration locations:${NC}"
echo "  • QuickShell: ~/.config/quickshell"
echo "  • Hyprland: ~/.config/hypr"
echo "  • Themes: ~/.config/gtk-*/Kvantum/qt*ct"
echo ""
echo -e "${YELLOW}Troubleshooting:${NC}"
echo "  • If QuickShell doesn't start: quickshell"
echo "  • Check logs: journalctl --user -xe | grep quickshell"
echo "  • Plymouth: sudo plymouth-set-default-theme"
echo ""
echo -e "${MAGENTA}Enjoy your Gruvbox desktop! ☕${NC}"
echo ""
