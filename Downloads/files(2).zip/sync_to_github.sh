#!/bin/bash

set -e

echo "=== End-4 Gruvbox GitHub Sync Script ==="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;36m'
NC='\033[0m'

# Configuration
REPO_NAME="end4-gruvbox-dots"
GITHUB_USER="davidbuckleyni"  # Update if different
SYNC_DIR="/home/david/Projects/$REPO_NAME"

echo -e "${BLUE}This script will sync your complete Gruvbox setup to GitHub${NC}"
echo ""
echo "What will be included:"
echo "  • QuickShell configuration (with media/swap fixes)"
echo "  • Plymouth Rubik's Cube boot animation"
echo "  • GTK/Qt/Kvantum Gruvbox themes"
echo "  • Dolphin file manager theming"
echo "  • Oreo Gruvbox hyprcursor"
echo "  • Hyprland configuration"
echo "  • All End-4 customizations"
echo ""

read -p "Continue? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
fi

# Create/update repository directory
echo -e "${YELLOW}[1/10] Setting up repository directory...${NC}"
mkdir -p "$SYNC_DIR"
cd "$SYNC_DIR"

# Initialize git if needed
if [ ! -d ".git" ]; then
    echo "  - Initializing git repository..."
    git init
    git remote add origin "https://github.com/$GITHUB_USER/$REPO_NAME.git" 2>/dev/null || true
else
    echo "  - Git repository already initialized"
fi

echo -e "${GREEN}  ✓ Repository ready${NC}"
echo ""

# ============================================================================
# QUICKSHELL CONFIGURATION
# ============================================================================
echo -e "${YELLOW}[2/10] Syncing QuickShell configuration...${NC}"

mkdir -p "$SYNC_DIR/config/quickshell"
echo "  - Copying QuickShell files..."
cp -r /home/david/.config/quickshell/* "$SYNC_DIR/config/quickshell/" 2>/dev/null || true

# Highlight the fixed files
echo "  - Key fixes included:"
echo "    ✓ Media.qml (width constraint, text padding, smooth scroll)"
echo "    ✓ Resources.qml (swap icon always visible)"

echo -e "${GREEN}  ✓ QuickShell synced${NC}"
echo ""

# ============================================================================
# HYPRLAND CONFIGURATION
# ============================================================================
echo -e "${YELLOW}[3/10] Syncing Hyprland configuration...${NC}"

mkdir -p "$SYNC_DIR/config/hypr"
echo "  - Copying Hyprland config..."
cp -r /home/david/.config/hypr/* "$SYNC_DIR/config/hypr/" 2>/dev/null || true

echo -e "${GREEN}  ✓ Hyprland synced${NC}"
echo ""

# ============================================================================
# PLYMOUTH BOOT ANIMATION
# ============================================================================
echo -e "${YELLOW}[4/10] Syncing Plymouth boot animation...${NC}"

mkdir -p "$SYNC_DIR/plymouth/gruvbox-rubiks"
if [ -d "/usr/share/plymouth/themes/gruvbox-rubiks" ]; then
    echo "  - Copying Gruvbox Rubik's Cube theme..."
    sudo cp -r /usr/share/plymouth/themes/gruvbox-rubiks/* "$SYNC_DIR/plymouth/gruvbox-rubiks/"
    
    FRAME_COUNT=$(ls -1 "$SYNC_DIR/plymouth/gruvbox-rubiks"/frame_*.png 2>/dev/null | wc -l)
    echo "  - Frames: $FRAME_COUNT"
    echo "  - Features: Plays once, holds on final frame, Gruvbox colors"
else
    echo "  - Plymouth theme not found (will need to be added manually)"
fi

# Add Plymouth documentation
cat > "$SYNC_DIR/plymouth/README.md" << 'PLYMOUTHREADME'
# Plymouth Gruvbox Rubik's Cube Boot Animation

## Features
- Animated Gruvbox-themed Rubik's Cube
- 36 frames at 1920x1080 resolution
- Plays through once and holds on final frame
- Gruvbox dark background (#282828)
- ~15fps smooth animation

## Installation
```bash
sudo cp -r gruvbox-rubiks /usr/share/plymouth/themes/
sudo plymouth-set-default-theme gruvbox-rubiks
sudo mkinitcpio -P
```

## Requirements
- Plymouth
- Grub bootloader with `quiet splash` parameters

See main install script for automated installation.
PLYMOUTHREADME

echo -e "${GREEN}  ✓ Plymouth synced${NC}"
echo ""

# ============================================================================
# GTK/QT THEMES
# ============================================================================
echo -e "${YELLOW}[5/10] Syncing GTK/Qt themes...${NC}"

mkdir -p "$SYNC_DIR/themes/gtk"
mkdir -p "$SYNC_DIR/themes/qt"

echo "  - Copying GTK configurations..."
cp -r /home/david/.config/gtk-3.0 "$SYNC_DIR/themes/gtk/" 2>/dev/null || true
cp -r /home/david/.config/gtk-4.0 "$SYNC_DIR/themes/gtk/" 2>/dev/null || true

echo "  - Copying Qt/Kvantum themes..."
cp -r /home/david/.config/Kvantum "$SYNC_DIR/themes/qt/" 2>/dev/null || true
cp -r /home/david/.config/qt5ct "$SYNC_DIR/themes/qt/" 2>/dev/null || true
cp -r /home/david/.config/qt6ct "$SYNC_DIR/themes/qt/" 2>/dev/null || true

echo "  - Copying color schemes..."
mkdir -p "$SYNC_DIR/themes/color-schemes"
cp /home/david/.local/share/color-schemes/*.colors "$SYNC_DIR/themes/color-schemes/" 2>/dev/null || true

# Copy kdeglobals if present
cp /home/david/.config/kdeglobals "$SYNC_DIR/themes/" 2>/dev/null || true

echo -e "${GREEN}  ✓ Themes synced${NC}"
echo ""

# ============================================================================
# DOLPHIN CONFIGURATION
# ============================================================================
echo -e "${YELLOW}[6/10] Syncing Dolphin configuration...${NC}"

mkdir -p "$SYNC_DIR/config/dolphin"
echo "  - Copying Dolphin settings..."
cp /home/david/.config/dolphinrc "$SYNC_DIR/config/dolphin/" 2>/dev/null || true
cp -r /home/david/.local/share/dolphin "$SYNC_DIR/config/dolphin/local-share" 2>/dev/null || true

echo -e "${GREEN}  ✓ Dolphin synced${NC}"
echo ""

# ============================================================================
# HYPRCURSOR (OREO GRUVBOX)
# ============================================================================
echo -e "${YELLOW}[7/10] Syncing Hyprcursor theme...${NC}"

mkdir -p "$SYNC_DIR/themes/cursors"
echo "  - Copying Oreo Gruvbox cursor theme..."

# Check common cursor locations
if [ -d "/home/david/.local/share/icons/Oreo-Gruvbox" ]; then
    cp -r /home/david/.local/share/icons/Oreo-Gruvbox "$SYNC_DIR/themes/cursors/" 2>/dev/null || true
    echo "  - Oreo Gruvbox cursor theme found and copied"
elif [ -d "/home/david/.icons/Oreo-Gruvbox" ]; then
    cp -r /home/david/.icons/Oreo-Gruvbox "$SYNC_DIR/themes/cursors/" 2>/dev/null || true
    echo "  - Oreo Gruvbox cursor theme found and copied"
else
    echo "  - Cursor theme not found in standard locations"
fi

# Copy hyprcursor config
cp /home/david/.config/hypr/hyprcursor.conf "$SYNC_DIR/config/hypr/" 2>/dev/null || true

echo -e "${GREEN}  ✓ Hyprcursor synced${NC}"
echo ""

# ============================================================================
# ADDITIONAL CONFIGURATIONS
# ============================================================================
echo -e "${YELLOW}[8/10] Syncing additional configurations...${NC}"

mkdir -p "$SYNC_DIR/config/misc"

# Terminal configs
cp -r /home/david/.config/kitty "$SYNC_DIR/config/misc/" 2>/dev/null || true
cp -r /home/david/.config/alacritty "$SYNC_DIR/config/misc/" 2>/dev/null || true

# Rofi/Wofi
cp -r /home/david/.config/rofi "$SYNC_DIR/config/misc/" 2>/dev/null || true
cp -r /home/david/.config/wofi "$SYNC_DIR/config/misc/" 2>/dev/null || true

# Waybar (if used)
cp -r /home/david/.config/waybar "$SYNC_DIR/config/misc/" 2>/dev/null || true

# Fonts
mkdir -p "$SYNC_DIR/fonts"
cp -r /home/david/.local/share/fonts/* "$SYNC_DIR/fonts/" 2>/dev/null || true

echo -e "${GREEN}  ✓ Additional configs synced${NC}"
echo ""

# ============================================================================
# PACKAGE LISTS
# ============================================================================
echo -e "${YELLOW}[9/10] Generating package lists...${NC}"

mkdir -p "$SYNC_DIR/packages"
echo "  - Saving package information..."

pacman -Qe > "$SYNC_DIR/packages/explicitly-installed.txt"
pacman -Qq > "$SYNC_DIR/packages/all-packages.txt"
pacman -Qm > "$SYNC_DIR/packages/aur-packages.txt" 2>/dev/null || true

# Create specific lists
pacman -Q | grep -E "gtk|qt|kvantum|gruvbox" > "$SYNC_DIR/packages/theme-packages.txt" 2>/dev/null || true
pacman -Q | grep -E "plymouth|hypr|quickshell" > "$SYNC_DIR/packages/desktop-packages.txt" 2>/dev/null || true

echo -e "${GREEN}  ✓ Package lists generated${NC}"
echo ""

# ============================================================================
# CREATE DOCUMENTATION
# ============================================================================
echo -e "${YELLOW}[10/10] Creating documentation...${NC}"

cat > "$SYNC_DIR/README.md" << 'MAINREADME'
# End-4 Gruvbox Desktop Environment

A complete, beautiful Gruvbox-themed desktop environment for CachyOS/Arch Linux featuring Hyprland, QuickShell, and extensive customization.

![Desktop Screenshot](screenshots/desktop.png)

## ✨ Features

### 🎨 Visual Design
- **Complete Gruvbox theming** across all applications
- **Custom Plymouth boot animation** - Animated Rubik's Cube that solves itself
- **Oreo Gruvbox cursor theme** - Custom hyprcursor integration
- **Consistent theming** for GTK3/4, Qt5/6, and KDE applications

### 🖥️ Desktop Environment
- **Hyprland** - Modern Wayland compositor
- **QuickShell (End-4 II)** - Beautiful, functional status bar with:
  - Media player with smooth scrolling text
  - System resource monitors (CPU, RAM, Swap)
  - Network, Bluetooth, and volume indicators
  - Weather widget
  - Workspace management

### 🎯 Key Improvements
- ✅ Media player text scrolls smoothly with proper padding
- ✅ Swap usage icon always visible (no longer hidden by media)
- ✅ Plymouth boot animation plays once and holds on final frame
- ✅ Dolphin file manager fully integrated with Gruvbox theme
- ✅ All Qt/GTK applications use consistent Gruvbox colors

## 📦 What's Included

```
end4-gruvbox-dots/
├── config/
│   ├── quickshell/          # QuickShell bar configuration
│   ├── hypr/                 # Hyprland window manager
│   ├── dolphin/              # File manager settings
│   └── misc/                 # Terminal, rofi, etc.
├── themes/
│   ├── gtk/                  # GTK 3/4 configurations
│   ├── qt/                   # Qt5/6 + Kvantum themes
│   ├── cursors/              # Oreo Gruvbox hyprcursor
│   └── color-schemes/        # KDE color schemes
├── plymouth/
│   └── gruvbox-rubiks/       # Boot animation (36 frames)
├── fonts/                    # Required fonts
├── packages/                 # Package lists
├── screenshots/              # Desktop screenshots
└── install.sh                # Automated installer
```

## 🚀 Quick Install

### Prerequisites
- Fresh CachyOS or Arch Linux installation
- AUR helper installed (yay/paru)
- Internet connection

### One-Command Install
```bash
git clone https://github.com/davidbuckleyni/end4-gruvbox-dots.git
cd end4-gruvbox-dots
chmod +x install.sh
./install.sh
```

The install script will:
1. Install all required packages
2. Set up Hyprland and QuickShell
3. Apply Gruvbox themes system-wide
4. Configure Plymouth boot animation
5. Set up Dolphin file manager
6. Install Oreo Gruvbox cursor theme
7. Configure all applications

### Manual Installation
See [INSTALL.md](INSTALL.md) for step-by-step manual installation instructions.

## 📸 Screenshots

### Desktop
![Main Desktop](screenshots/desktop.png)

### QuickShell Bar
![Status Bar](screenshots/bar.png)

### Plymouth Boot
![Boot Animation](screenshots/plymouth.gif)

### Applications
![Dolphin File Manager](screenshots/dolphin.png)

## 🎨 Color Palette

The Gruvbox color scheme used throughout:

| Color | Hex | Usage |
|-------|-----|-------|
| Background | `#282828` | Main background |
| Foreground | `#ebdbb2` | Main text |
| Red | `#fb4934` | CPU monitor, warnings |
| Orange | `#d65d0e` | Media player accent |
| Yellow | `#fabd2f` | Memory monitor |
| Blue | `#458588` | Swap monitor |
| Green | `#b8bb26` | Success states |
| Purple | `#d3869b` | Highlights |

## 🔧 Configuration

### QuickShell Bar
Located in `config/quickshell/ii/modules/ii/bar/`

Key files:
- `Media.qml` - Media player component (width: max 200px)
- `Resources.qml` - System monitors (swap always visible)
- `BarContent.qml` - Overall bar layout

### Hyprland
Located in `config/hypr/`

Main configuration: `hyprland.conf`

### Plymouth
Located in `plymouth/gruvbox-rubiks/`

Features:
- 36 frames at 1920x1080
- Plays once and holds on final frame
- Smooth 15fps animation

## 📝 Customization

### Change Bar Width Limits
Edit `config/quickshell/ii/modules/ii/bar/Media.qml`:
```qml
Layout.maximumWidth: 200  // Change this value
```

### Adjust Scroll Speed
Edit `config/quickshell/ii/modules/ii/bar/Media.qml`:
```qml
duration: 8000  // Milliseconds for full scroll
```

### Plymouth Animation Speed
Edit `plymouth/gruvbox-rubiks/gruvbox-rubiks.script`:
```qml
global.frame_delay = 4;  // Lower = faster
```

### Theme Colors
GTK: Edit `themes/gtk/gtk-3.0/settings.ini`
Qt: Use `kvantummanager` to adjust themes

## 🐛 Troubleshooting

### QuickShell not starting
```bash
# Check logs
journalctl --user -xe | grep quickshell

# Run manually to see errors
quickshell
```

### Plymouth animation not showing
```bash
# Verify kernel parameters
cat /proc/cmdline | grep "quiet splash"

# Check if theme is set
sudo plymouth-set-default-theme

# Rebuild initramfs
sudo mkinitcpio -P
```

### Themes not applying
```bash
# Reload GTK settings
gsettings set org.gnome.desktop.interface gtk-theme "Gruvbox-Dark"

# For Qt applications
kvantummanager
```

### Swap icon disappearing
If you've customized `Resources.qml`, ensure line 27-29 includes:
```qml
shown: ... || true  // Always show
```

## 📚 Documentation

- [Installation Guide](INSTALL.md) - Detailed installation steps
- [Customization Guide](CUSTOMIZE.md) - How to personalize your setup
- [Troubleshooting](TROUBLESHOOTING.md) - Common issues and solutions
- [Package List](packages/) - All required packages

## 🤝 Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## 📜 License

This configuration is free to use and modify. Attribution appreciated but not required.

## 🙏 Credits

- **End-4 dots** - Base QuickShell configuration
- **Gruvbox** - Incredible color scheme by morhetz
- **Oreo cursors** - Modified for Gruvbox colors
- **Plymouth Rubik's Cube** - Custom animated boot splash

## 📧 Contact

- GitHub: [@davidbuckleyni](https://github.com/davidbuckleyni)
- Issues: [GitHub Issues](https://github.com/davidbuckleyni/end4-gruvbox-dots/issues)

---

**Note**: This is a living configuration that's constantly being improved. Star ⭐ the repo to stay updated!
MAINREADME

# Create install script documentation
cat > "$SYNC_DIR/INSTALL.md" << 'INSTALLMD'
# Detailed Installation Guide

## Prerequisites

### System Requirements
- CachyOS or Arch Linux (fresh or existing installation)
- At least 4GB RAM
- 20GB free disk space
- Internet connection

### Required Base Packages
The install script will handle most of this, but for manual installation:
```bash
# Base development
sudo pacman -S base-devel git

# AUR helper (choose one)
# Yay
git clone https://aur.archlinux.org/yay.git && cd yay && makepkg -si

# Paru
git clone https://aur.archlinux.org/paru.git && cd paru && makepkg -si
```

## Automated Installation

### 1. Clone Repository
```bash
cd ~
git clone https://github.com/davidbuckleyni/end4-gruvbox-dots.git
cd end4-gruvbox-dots
```

### 2. Review Configuration
Before running the installer, you may want to review:
- Package lists in `packages/`
- Configuration files in `config/`
- Theme files in `themes/`

### 3. Run Installer
```bash
chmod +x install.sh
./install.sh
```

The installer will prompt you at each major step:
- Package installation
- Configuration deployment
- Theme application
- Plymouth setup
- Service enablement

### 4. Post-Installation
After installation completes:
```bash
# Reboot to see Plymouth animation
reboot
```

## Manual Installation

If you prefer to install components individually:

### 1. Install Packages

#### Core Desktop
```bash
# Hyprland and Wayland essentials
sudo pacman -S hyprland xdg-desktop-portal-hyprland qt5-wayland qt6-wayland

# QuickShell (from AUR)
yay -S quickshell-git
```

#### Themes and Appearance
```bash
# GTK themes
sudo pacman -S gtk3 gtk4

# Qt theming
sudo pacman -S qt5ct qt6ct kvantum

# Fonts
sudo pacman -S ttf-jetbrains-mono-nerd ttf-font-awesome
```

#### Plymouth
```bash
sudo pacman -S plymouth
```

#### Applications
```bash
# File manager
sudo pacman -S dolphin

# Terminal (choose your preference)
sudo pacman -S kitty  # or alacritty
```

### 2. Deploy Configurations

#### QuickShell
```bash
mkdir -p ~/.config/quickshell
cp -r config/quickshell/* ~/.config/quickshell/
```

#### Hyprland
```bash
mkdir -p ~/.config/hypr
cp -r config/hypr/* ~/.config/hypr/
```

#### Themes
```bash
# GTK
mkdir -p ~/.config/gtk-3.0 ~/.config/gtk-4.0
cp -r themes/gtk/gtk-3.0/* ~/.config/gtk-3.0/
cp -r themes/gtk/gtk-4.0/* ~/.config/gtk-4.0/

# Qt/Kvantum
mkdir -p ~/.config/Kvantum
cp -r themes/qt/Kvantum/* ~/.config/Kvantum/

# Color schemes
mkdir -p ~/.local/share/color-schemes
cp themes/color-schemes/*.colors ~/.local/share/color-schemes/
```

#### Cursors
```bash
mkdir -p ~/.local/share/icons
cp -r themes/cursors/Oreo-Gruvbox ~/.local/share/icons/
```

### 3. Install Plymouth Theme

```bash
# Copy theme
sudo cp -r plymouth/gruvbox-rubiks /usr/share/plymouth/themes/

# Set as default
sudo plymouth-set-default-theme gruvbox-rubiks

# Add plymouth to mkinitcpio hooks
sudo nano /etc/mkinitcpio.conf
# Add 'plymouth' to HOOKS array after 'base' and 'udev'

# Rebuild initramfs
sudo mkinitcpio -P

# Update GRUB
sudo nano /etc/default/grub
# Add 'quiet splash' to GRUB_CMDLINE_LINUX_DEFAULT
sudo grub-mkconfig -o /boot/grub/grub.cfg
```

### 4. Configure Applications

#### Dolphin
```bash
cp config/dolphin/dolphinrc ~/.config/
```

#### Terminal (Kitty example)
```bash
mkdir -p ~/.config/kitty
cp config/misc/kitty/* ~/.config/kitty/
```

### 5. Install Fonts
```bash
mkdir -p ~/.local/share/fonts
cp -r fonts/* ~/.local/share/fonts/
fc-cache -fv
```

### 6. Enable Services
```bash
# QuickShell (user service)
systemctl --user enable quickshell
systemctl --user start quickshell

# Hyprland starts from display manager or .xinitrc
```

## Verification

### Check Installations
```bash
# QuickShell
quickshell --version

# Hyprland
hyprctl version

# Plymouth
plymouth-set-default-theme
```

### Test Components

#### QuickShell Bar
```bash
# Should start automatically, or run:
quickshell
```

#### Hyprland
Log out and select Hyprland from your display manager

#### Plymouth
```bash
# Test without rebooting
sudo plymouthd
sudo plymouth --show-splash
sleep 5
sudo plymouth quit
```

## Troubleshooting

See [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common issues and solutions.

## Next Steps

After installation:
1. Review [CUSTOMIZE.md](CUSTOMIZE.md) for personalization options
2. Set up your applications and workflows
3. Take screenshots and enjoy your Gruvbox desktop!
INSTALLMD

# Set ownership
sudo chown -R david:david "$SYNC_DIR" 2>/dev/null || sudo chown -R 1000:1000 "$SYNC_DIR"

echo -e "${GREEN}  ✓ Documentation created${NC}"
echo ""

# ============================================================================
# GIT OPERATIONS
# ============================================================================
echo -e "${YELLOW}Preparing Git commit...${NC}"
echo ""

cd "$SYNC_DIR"

# Create .gitignore
cat > .gitignore << 'GITIGNORE'
# Sensitive files
**/passwords.txt
**/secrets.txt
**/.env

# Cache and temporary files
**/__pycache__/
**/*.pyc
**/.cache/
**/cache/

# Backup files
**/*.backup
**/*.bak
**/*~

# Large binary files (optional)
# **/*.png
# **/*.jpg

# System files
.DS_Store
Thumbs.db
GITIGNORE

# Add all files
git add .

echo "Files staged for commit:"
git status --short

echo ""
echo -e "${BLUE}Ready to commit and push!${NC}"
echo ""
echo "Next steps:"
echo "  1. Review staged files above"
echo "  2. Run: git commit -m 'Complete Gruvbox setup with all improvements'"
echo "  3. Run: git push -u origin main"
echo ""
echo "Or run this script's companion: ./push_to_github.sh"
echo ""

# Create push script
cat > "$SYNC_DIR/push_to_github.sh" << 'PUSHSCRIPT'
#!/bin/bash

echo "=== Pushing to GitHub ==="
echo ""

# Check if there are changes
if [[ -z $(git status -s) ]]; then
    echo "No changes to commit."
    exit 0
fi

# Commit
echo "Committing changes..."
read -p "Enter commit message (or press Enter for default): " COMMIT_MSG

if [ -z "$COMMIT_MSG" ]; then
    COMMIT_MSG="Update Gruvbox configuration - $(date +%Y-%m-%d)"
fi

git commit -m "$COMMIT_MSG"

# Push
echo ""
echo "Pushing to GitHub..."
git push -u origin main || git push -u origin master

echo ""
echo "✓ Successfully pushed to GitHub!"
echo ""
echo "View your repository at:"
echo "https://github.com/davidbuckleyni/end4-gruvbox-dots"
PUSHSCRIPT

chmod +x "$SYNC_DIR/push_to_github.sh"

echo -e "${GREEN}=== Sync Complete! ===${NC}"
echo ""
echo -e "Repository location: ${BLUE}$SYNC_DIR${NC}"
echo ""
echo "What's been synced:"
echo "  ✓ QuickShell configuration (with all fixes)"
echo "  ✓ Plymouth Rubik's Cube boot animation"
echo "  ✓ Complete Gruvbox theme files"
echo "  ✓ Dolphin configuration"
echo "  ✓ Oreo Gruvbox cursor theme"
echo "  ✓ Hyprland configuration"
echo "  ✓ Package lists"
echo "  ✓ Complete documentation"
echo "  ✓ Install scripts"
echo ""
echo "To push to GitHub:"
echo "  cd $SYNC_DIR"
echo "  ./push_to_github.sh"
echo ""
