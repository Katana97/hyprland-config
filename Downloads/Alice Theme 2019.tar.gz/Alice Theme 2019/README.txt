font image background:
http://www.candicreations.com/notebook/creative/set-the-tone/
font theme:
https://www.youtube.com/user/TheLABNET

Alice :: Music or Al1c3

Doe bitcoins para a continuidade do projeto:
Donate bitcoins for project continuity:
Doe bitcoins para la continuidad del proyecto:

1Nmd6ZW3u7R9pT1DwpEKMAYihXpH3DcndG

╔══╗ ♫
║██║ ♪♪
║██║♫♪ ║ ◎♫♪♫
╚══╝

Turn Up The Music!!!
