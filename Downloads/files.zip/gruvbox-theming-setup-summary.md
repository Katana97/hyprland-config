# End-4 Dots Gruvbox Theming Setup - Complete Guide

## Summary
Successfully configured end-4 dots (QuickShell) on CachyOS/Hyprland to use pure Gruvbox theming instead of MaterialYou wallpaper-based colors, with a working light/dark toggle.

## What Works
- ✅ Light/Dark bar toggle switches entire system theme
- ✅ GTK apps (Firefox, etc.) update instantly
- ✅ Icon theme switches: Gruvbox-Plus-Dark ↔ Gruvbox-Plus-Light
- ✅ GTK theme switches: Gruvbox-Dark-Compact-Soft ↔ Gruvbox-Light-Compact-Soft
- ✅ Dolphin uses Gruvbox colors (requires manual restart after toggle)
- ✅ MaterialYou wallpaper colors no longer override Gruvbox

## Key Files Modified

### 1. `~/.config/quickshell/ii/scripts/colors/switchwall.sh`
**Changes:**
- Commented out `kde-material-you-colors-wrapper.sh` call in `handle_kde_material_you_colors()` (line 34)
- Added conditional `apply-gruvbox.sh` call after matugen (lines 310-315)
- Calls `GruvboxPlusDark` for dark mode, `GruvboxPlusLight` for light mode

**Key additions:**
```bash
# After matugen call (around line 310):
if [[ "$(jq -r .appearance.lightMode "$SHELL_CONFIG_FILE")" == "true" ]]; then
    ~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh GruvboxPlusLight
else
    ~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh GruvboxPlusDark
fi
```

### 2. `~/.config/quickshell/ii/modules/ii/bar/UtilButtons.qml`
**Changes:**
- Changed dark mode detection from `Appearance.m3colors.darkmode` to `Config.options.appearance.lightMode`
- Fixed icon display logic (shows sun for light, moon for dark)
- Fixed Hyprland.dispatch syntax (removed template literal issues)

**Key section:**
```qml
onClicked: event => {
    if (!Config.options.appearance.lightMode) {
        Hyprland.dispatch("exec " + Directories.wallpaperSwitchScriptPath + " --mode light --noswitch");
    } else {
        Hyprland.dispatch("exec " + Directories.wallpaperSwitchScriptPath + " --mode dark --noswitch");
    }
}
MaterialSymbol {
    text: Config.options.appearance.lightMode ? "light_mode" : "dark_mode"
}
```

### 3. `~/.config/quickshell/ii/modules/common/Config.qml`
**Changes:**
- Added `property bool lightMode: false` to the appearance section (after palette definition)

### 4. `~/.config/matugen/templates/kde/kde-material-you-colors-wrapper.sh`
**Changes:**
- Commented out the actual `kde-material-you-colors` command call

### 5. Created `~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh`
**Purpose:** Forces Gruvbox color scheme to kdeglobals, overriding MaterialYou colors

**Script functionality:**
- Backs up kdeglobals
- Removes all [Colors:*] sections from kdeglobals
- Replaces them with colors from the specified Gruvbox .colors file
- Sets the ColorScheme name

### 6. `~/.config/kde-material-you-colors/config.conf`
**Changes:**
```ini
iconslight = Gruvbox-Plus-Light
iconsdark = Gruvbox-Plus-Dark
```

### 7. `~/.config/dolphinrc`
**Changes:**
- Removed hardcoded `ColorScheme=GruvboxColors` line to allow dynamic switching

## Dependencies Installed

### Gruvbox GTK Theme
**Source:** https://github.com/Fausto-Korpsvart/Gruvbox-GTK-Theme
**Installation:**
```bash
cd ~/Downloads
git clone https://github.com/Fausto-Korpsvart/Gruvbox-GTK-Theme.git
cd Gruvbox-GTK-Theme/themes
./install.sh -c dark -c light -t all -s compact --tweaks soft outline float
```
**Installed to:** `~/.themes/Gruvbox-*-Compact-Soft/`

### Gruvbox KDE Color Schemes
**Source:** https://github.com/SylEleuth/gruvbox-plus-kde
**Installation:**
```bash
cd /tmp
git clone https://github.com/SylEleuth/gruvbox-plus-kde
cp gruvbox-plus-kde/color-scheme/*.colors ~/.local/share/color-schemes/
```
**Files:**
- `~/.local/share/color-schemes/GruvboxPlusDark.colors`
- `~/.local/share/color-schemes/GruvboxPlusLight.colors`

### Icon Theme
Already installed: Gruvbox-Plus-Dark and Gruvbox-Plus-Light

## How It Works

### Execution Flow
1. User clicks light/dark toggle on bar
2. Bar checks current `Config.options.appearance.lightMode` value
3. Calls `switchwall.sh --mode [light|dark] --noswitch`
4. `pre_process()` runs:
   - Updates gsettings for GTK apps (gtk-theme, icon-theme, color-scheme)
   - Updates lightMode in config JSON
   - Updates KDE color scheme names in dolphinrc and kdeglobals
5. `matugen` runs (generates MaterialYou colors from wallpaper)
6. **`apply-gruvbox.sh` runs** (overwrites MaterialYou colors with Gruvbox)
7. GTK apps update instantly
8. Dolphin needs manual restart to show new colors

### Why apply-gruvbox.sh is Needed
- Matugen always generates MaterialYou colors from the wallpaper
- These colors get written to kdeglobals `[Colors:*]` sections
- Even though ColorScheme name is set to "GruvboxPlusDark", the actual RGB values are MaterialYou
- `apply-gruvbox.sh` reads the correct Gruvbox .colors file and replaces all `[Colors:*]` sections
- This ensures Dolphin and other Qt apps use actual Gruvbox colors

## Troubleshooting

### Dolphin still shows MaterialYou colors
**Solution:** Restart Dolphin after toggling theme
```bash
killall dolphin
dolphin &
```

### Colors revert to MaterialYou after system restart
**Check:** Ensure all modifications to switchwall.sh are still present
**Check:** Ensure apply-gruvbox.sh has execute permissions
```bash
chmod +x ~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh
```

### Bar toggle doesn't work
**Check:** Config.qml has lightMode property
**Check:** UtilButtons.qml uses correct syntax
**Restart:** QuickShell
```bash
killall qs quickshell
qs -c ii &
```

### GTK apps don't update instantly
**Check:** gsettings commands in pre_process()
**Check:** GTK theme files exist
```bash
ls ~/.themes/ | grep Gruvbox
```

## Files to Backup

Essential files for replicating this setup:
1. `~/.config/quickshell/ii/scripts/colors/switchwall.sh`
2. `~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh`
3. `~/.config/quickshell/ii/modules/ii/bar/UtilButtons.qml`
4. `~/.config/quickshell/ii/modules/common/Config.qml`
5. `~/.config/matugen/templates/kde/kde-material-you-colors-wrapper.sh`
6. `~/.config/kde-material-you-colors/config.conf`
7. `~/.config/dolphinrc`
8. `~/.themes/Gruvbox-*-Compact-Soft/` (directories)
9. `~/.local/share/color-schemes/GruvboxPlus*.colors`

## Debug Commands

```bash
# Check current theme state
cat ~/.config/illogical-impulse/config.json | jq '.appearance.lightMode'
grep "ColorScheme=" ~/.config/kdeglobals
grep "DecorationFocus" ~/.config/kdeglobals | head -1

# Check if scripts are executing
tail -20 /tmp/switchwall-debug.log

# Manually test color scheme application
~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh GruvboxPlusDark
~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh GruvboxPlusLight

# Check GTK settings
gsettings get org.gnome.desktop.interface gtk-theme
gsettings get org.gnome.desktop.interface icon-theme
gsettings get org.gnome.desktop.interface color-scheme
```

## Credits
- Gruvbox color scheme: https://github.com/morhetz/gruvbox
- Gruvbox GTK Theme: https://github.com/Fausto-Korpsvart/Gruvbox-GTK-Theme
- Gruvbox Plus KDE: https://github.com/SylEleuth/gruvbox-plus-kde
- Gruvbox Plus Icons: https://github.com/SylEleuth/gruvbox-plus-icon-pack
- end-4 dots: https://github.com/end-4/dots-hyprland

## Date
Created: January 17, 2026
System: CachyOS with Hyprland + end-4 dots (QuickShell)
