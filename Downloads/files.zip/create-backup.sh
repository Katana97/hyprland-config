#!/bin/bash
# Gruvbox Theming Backup Script
# Run this as your user (not root)

BACKUP_DIR="/mnt/user-data/outputs/end4-gruvbox-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"/{scripts,configs,themes}

echo "Creating backup at: $BACKUP_DIR"

# Backup scripts
cp ~/.config/quickshell/ii/scripts/colors/switchwall.sh "$BACKUP_DIR/scripts/"
cp ~/.config/quickshell/ii/scripts/colors/apply-gruvbox.sh "$BACKUP_DIR/scripts/"

# Backup configs
cp ~/.config/quickshell/ii/modules/ii/bar/UtilButtons.qml "$BACKUP_DIR/configs/"
cp ~/.config/quickshell/ii/modules/common/Config.qml "$BACKUP_DIR/configs/"
cp ~/.config/matugen/templates/kde/kde-material-you-colors-wrapper.sh "$BACKUP_DIR/configs/"
cp ~/.config/kde-material-you-colors/config.conf "$BACKUP_DIR/configs/"
cp ~/.config/dolphinrc "$BACKUP_DIR/configs/"

# Backup color schemes
cp ~/.local/share/color-schemes/GruvboxPlus*.colors "$BACKUP_DIR/themes/" 2>/dev/null

# Create README
cat > "$BACKUP_DIR/README.md" << 'EOFREADME'
# End-4 Gruvbox Theming Backup

This backup contains all modified files for the Gruvbox theming setup.

## Files Included

### Scripts
- `switchwall.sh` - Main theme switching script
- `apply-gruvbox.sh` - Script that applies Gruvbox colors to kdeglobals

### Configs
- `UtilButtons.qml` - Bar button with fixed light/dark toggle
- `Config.qml` - QuickShell config with lightMode property
- `kde-material-you-colors-wrapper.sh` - Modified to not overwrite colors
- `config.conf` - KDE Material You Colors config with Gruvbox icons
- `dolphinrc` - Dolphin configuration

### Themes
- `GruvboxPlusDark.colors` - KDE dark color scheme
- `GruvboxPlusLight.colors` - KDE light color scheme

## To Restore

1. Copy scripts to: `~/.config/quickshell/ii/scripts/colors/`
2. Copy configs to their respective locations (see filenames)
3. Copy color schemes to: `~/.local/share/color-schemes/`
4. Make scripts executable: `chmod +x ~/.config/quickshell/ii/scripts/colors/*.sh`
5. Restart QuickShell: `killall qs quickshell && qs -c ii &`

## Full Documentation

See `gruvbox-theming-setup-summary.md` for complete documentation.
EOFREADME

echo ""
echo "✅ Backup created successfully!"
echo "📁 Location: $BACKUP_DIR"
echo ""
echo "Backup contents:"
ls -lh "$BACKUP_DIR"
find "$BACKUP_DIR" -type f
